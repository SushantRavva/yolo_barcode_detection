# Biscuit_detection > 2024-06-11 9:31pm
https://universe.roboflow.com/fynd/biscuit_detection-yctah

Provided by a Roboflow user
License: Public Domain

